close all;
clear all;
clc;

% figure 2a
figure
kc = 0.1;
ki = 0.05;
knc = 0.05;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
h1 = loglog(ku,Pi,'k','linewidth',7);
hold on

kc = 0.1;
ki = 0.05;
knc = 0.05;
ku = logspace(-4,2,61);
h10 = loglog(ku,ki*kc./ku.^2,'--k','linewidth',2);
hold on

kc = 0.01; %10x lower
ki = 0.05;
knc = 0.05;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
h2 = loglog(ku,Pi,'--','color',[0.24 0.59 0.17],'linewidth',2);

kc = 1; %10x higher
ki = 0.05;
knc = 0.05;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
h3 = loglog(ku,Pi,':','color',[0.24 0.59 0.17],'linewidth',2);

kc = 0.1;
ki = 0.05; 
knc = 0.005; %10x lower
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
h4 = loglog(ku,Pi,'m--','linewidth',2);

kc = 0.1;
ki = 0.05; 
knc = 0.5; %10x higher
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
h5 = loglog(ku,Pi,'m:','linewidth',2);

kc = 0.1;
ki = 0.005; %10x lower
knc = 0.05;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
h6 = loglog(ku,Pi,'b--','linewidth',2);

kc = 0.1;
ki = 0.5; %10x higher
knc = 0.05;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
h7 = loglog(ku,Pi,'b:','linewidth',2);

kc = 0.1;
ki = 0.05;
knc = 0.05;
clear ku
clear Pi
ku = 0.05;
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
h8 = loglog(ku,Pi,'ok','markersize',20,'LineWidth',3);

kc = 0.1;
ki = 0.05;
knc = 0.05;
clear ku
clear Pi
ku = 0.5;
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
h9 = loglog(ku,Pi,'o','color',[0.92 0.64 0.08],'markersize',20,'LineWidth',3);

set(gca,'fontsize',14)
xlabel('Ligand unbinding rate k_{u} (s^{-1})','fontsize',18);
ylabel('Internalization probability P_{i}', 'fontsize',18);
legend([h2 h3 h4 h5 h6 h7 h1], ...
    'k_{c} = 0.01 s^{-1}', ...
    'k_{c} = 1 s^{-1}', ...
    'k_{-c} = 0.005 s^{-1}', ...
    'k_{-c} = 0.5 s^{-1}', ...
    'k_{i} = 0.005 s^{-1}', ...
    'k_{i} = 0.5 s^{-1}', ...
    'k_{c} = 0.1 s^{-1}, k_{-c} = 0.05 s^{-1}, k_{i} = 0.05 s^{-1}','fontsize',16);
xlim([1e-3 1e1]);
ylim([2e-6 1])
box off
legend boxoff

%%

% figure 2b
figure
kc = 0.1;
ki = 0.05;
knc = 0.05;
A = 10;
ku = logspace(-4,2,61);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h1 = loglog(ku,fidelity,'k','linewidth',7);
hold on

kc = 0.01; %10x lower
ki = 0.05;
knc = 0.05;
A = 10;
ku = logspace(-4,2,61);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h2 = loglog(ku,fidelity,'--','color',[0.24 0.59 0.17],'linewidth',3);

kc = 1; %10x higher
ki = 0.05;
knc = 0.05;
A = 10;
ku = logspace(-4,2,61);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h3 = loglog(ku,fidelity,':','color',[0.24 0.59 0.17],'linewidth',3);

kc = 0.1; 
ki = 0.05; 
knc = 0.005; %10x lower
A = 10;
ku = logspace(-4,2,61);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h4 = loglog(ku,fidelity,'m--','linewidth',2);

kc = 0.1; 
ki = 0.05; 
knc = 0.5; %10x higher
A = 10;
ku = logspace(-4,2,61);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h5 = loglog(ku,fidelity,'m:','linewidth',2);

kc = 0.1; 
ki = 0.005; %10x lower
knc = 0.005; 
A = 10;
ku = logspace(-4,2,61);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h6 = loglog(ku,fidelity,'b--','linewidth',2);

kc = 0.1; 
ki = 0.5; %10x higher
knc = 0.5; 
A = 10;
ku = logspace(-4,2,61);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h7 = loglog(ku,fidelity,'b:','linewidth',2);

kc = 0.1;
ki = 0.05;
knc = 0.05;
A = 10;
ku = 0.05;
clear fidelity
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h8 = loglog(ku,fidelity,'ok','markersize',20,'LineWidth',3);

set(gca,'fontsize',14)
xlabel('Ligand unbinding rate k_{u} (s^{-1})','fontsize',18);
ylabel('Fidelity', 'fontsize',18);
legend([h2 h3 h4 h5 h6 h7 h1], ...
    'k_{c} = 0.01 s^{-1}', ...
    'k_{c} = 1 s^{-1}', ...
    'k_{-c} = 0.005 s^{-1}', ...
    'k_{-c} = 0.5 s^{-1}', ...
    'k_{i} = 0.005 s^{-1}', ...
    'k_{i} = 0.5 s^{-1}', ...
    'k_{c} = 0.1 s^{-1}, k_{-c} = 0.05 s^{-1}, k_{i} = 0.05 s^{-1}','fontsize',16);
xlim([1e-3 1e1]);
box off
legend boxoff

%%
%figure 2c
figure
kc = 0.1;
ki = 0.05;
knc = 0.05;
A = 10;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h1 = plot(Pi,fidelity,'k','linewidth',7);
hold on

kc = 0.01; %10x lower
ki = 0.05;
knc = 0.05;
A = 10;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h2 = plot(Pi,fidelity,'--','color',[0.24 0.59 0.17],'linewidth',3);

kc = 1; %10x higher
ki = 0.05;
knc = 0.05;
A = 10;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h3 = plot(Pi,fidelity,':','color',[0.24 0.59 0.17],'linewidth',5);

kc = 0.1; 
ki = 0.05; 
knc = 0.005; %10x lower
A = 10;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h4 = plot(Pi,fidelity,'m--','linewidth',2);

kc = 0.1; 
ki = 0.05; 
knc = 0.5; %10x higher
A = 10;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h5 = plot(Pi,fidelity,'m:','linewidth',2);

kc = 0.1; 
ki = 0.005; %10x lower
knc = 0.05; 
A = 10;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h6 = plot(Pi,fidelity,'b--','linewidth',2);

kc = 0.1; 
ki = 0.5; %10x higher
knc = 0.05; 
A = 10;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h7 = plot(Pi,fidelity,'b:','linewidth',2);

kc = 0.1;
ki = 0.05;
knc = 0.05;
A = 10;
ku = 0.05;
clear Pi
clear fidelity
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h8 = plot(Pi,fidelity,'ok','markersize',20,'LineWidth',3);

set(gca,'fontsize',14)
xlabel('Internalization probability P_{i}','fontsize',18);
ylabel('Fidelity', 'fontsize',18);
legend([h2 h3 h4 h5 h6 h7 h1], ...
    'k_{c} = 0.01 s^{-1}', ...
    'k_{c} = 1 s^{-1}', ...
    'k_{-c} = 0.005 s^{-1}', ...
    'k_{-c} = 0.5 s^{-1}', ...
    'k_{i} = 0.005 s^{-1}', ...
    'k_{i} = 0.5 s^{-1}', ...
    'k_{c} = 0.1 s^{-1}, k_{-c} = 0.05 s^{-1}, k_{i} = 0.05 s^{-1}','fontsize',16);
box off
legend boxoff
yticks([0 20 40 60 80 100]);

%%
%figure 2d
figure

logmin = -4;
logmax = 3;
for i=1:10000
    kc = 10^(logmin)*10^((logmax-logmin)*rand());
    ki = 10^(logmin)*10^((logmax-logmin)*rand());
    knc = 10^(logmin)*10^((logmax-logmin)*rand());
    ku = 10^(logmin)*10^((logmax-logmin)*rand());
    Pi_list(i) = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
    fidelity_list(i) = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
end
h01 = plot(Pi_list,fidelity_list,'.','color',[0.76 0.73 0.73],'markersize',15);
hold on

A = 10;
kscale = logspace(-3,3,101);
P_high = (1)./(1+kscale).^2;
F_high = (1 + A*kscale.*(2 + A*kscale))./(1 + kscale.*(2+kscale));
h11 = plot(P_high,F_high,'--k','linewidth',3);

A = 10;
kscale = logspace(-3,3,101);
P_low = (1)./(1+kscale);
F_low = (1 + A*kscale)./(1 + kscale);
h12 = plot(P_low,F_low,':k','linewidth',3);

kc = 0.1;
ki = 0.05;
knc = 0.05;
A = 10;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h13 = plot(Pi,fidelity,'k','linewidth',7);
hold on

kc = 0.1;
ki = 0.05;
knc = 0.05;
A = 10;
ku = 0.05;
clear Pi
clear fidelity
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
fidelity = (kc*ki + ku.*A.*(kc + ki + knc + A*ku))./(kc*ki + ku.*(kc + ki + knc + ku));
h8 = plot(Pi,fidelity,'ok','markersize',20,'LineWidth',3,'HandleVisibility','off');

set(gca,'fontsize',14)
xlabel('Internalization probability P_{i}','fontsize',18);
ylabel('Fidelity', 'fontsize',18);
legend([h01, h11, h12, h13], ...
    'Random parameter combinations', ...
    'High fidelity limit',...
    'Low fidelity limit',...
    'k_{c} = 0.1 s^{-1}, k_{-c} = 0.05 s^{-1}, k_{i} = 0.05 s^{-1}','fontsize',16);
box off
legend boxoff
yticks([0 20 40 60 80 100]);

%%
%figure 3a inset
figure
kc = 0.1;
ki = 0.05;
knc = 0.05;
clear ku
ku = 0.05;
probnumclathenter_EGF(1) = ku/(kc+ku);
for n=2:4
    probnumclathenter_EGF(n) = kc/(kc+ku)*((ki+ku)/(ki+ku+knc))*((knc/(ki+ku+knc))*(kc/(kc+ku)))^(n-2);
end

kc = 0.1;
ki = 0.05;
knc = 0.05;
clear ku
ku = 10*0.05;
probnumclathenter_notEGF(1) = ku/(kc+ku);
for n=2:4
    probnumclathenter_notEGF(n) = kc/(kc+ku)*((ki+ku)/(ki+ku+knc))*((knc/(ki+ku+knc))*(kc/(kc+ku)))^(n-2);
end

bar([0 1 2 3],[probnumclathenter_EGF;probnumclathenter_notEGF]);
set(gca,'fontsize',16)
xlabel('Number of clathrin entries','fontsize',20);
ylabel('Probability', 'fontsize',20);
box off
legend('EGF','EREG','fontsize',18);
legend boxoff

%%
%figure 3a
figure
kc = 0.1;
ki = 0.05;
knc = 0.05;
ku_list = logspace(-4,2,61);
for kui=1:length(ku_list)
    ku = ku_list(kui);
    probnumclathenter(1) = ku/(kc+ku);
    for n=2:101
        probnumclathenter(n) = kc/(kc+ku)*((ki+ku)/(ki+ku+knc))*((knc/(ki+ku+knc))*(kc/(kc+ku)))^(n-2);
    end
    nvals = linspace(0,100,101);
    meannumclathenter(kui) = sum(nvals .* probnumclathenter);
end
h1 = semilogx(ku_list,meannumclathenter,'k','linewidth',7);
hold on

kc = 0.01; %10x lower
ki = 0.05;
knc = 0.05;
ku_list = logspace(-4,2,61);
for kui=1:length(ku_list)
    ku = ku_list(kui);
    probnumclathenter(1) = ku/(kc+ku);
    for n=2:101
        probnumclathenter(n) = kc/(kc+ku)*((ki+ku)/(ki+ku+knc))*((knc/(ki+ku+knc))*(kc/(kc+ku)))^(n-2);
    end
    nvals = linspace(0,100,101);
    meannumclathenter(kui) = sum(nvals .* probnumclathenter);
end
h2 = semilogx(ku_list,meannumclathenter,'--','color',[0.24 0.59 0.17],'linewidth',2);

kc = 1; %10x higher
ki = 0.05;
knc = 0.05;
ku_list = logspace(-4,2,61);
for kui=1:length(ku_list)
    ku = ku_list(kui);
    probnumclathenter(1) = ku/(kc+ku);
    for n=2:101
        probnumclathenter(n) = kc/(kc+ku)*((ki+ku)/(ki+ku+knc))*((knc/(ki+ku+knc))*(kc/(kc+ku)))^(n-2);
    end
    nvals = linspace(0,100,101);
    meannumclathenter(kui) = sum(nvals .* probnumclathenter);
end
h3 = semilogx(ku_list,meannumclathenter,':','color',[0.24 0.59 0.17],'linewidth',2);

kc = 0.1;
ki = 0.05; 
knc = 0.005; %10x lower
ku_list = logspace(-4,2,61);
for kui=1:length(ku_list)
    ku = ku_list(kui);
    probnumclathenter(1) = ku/(kc+ku);
    for n=2:101
        probnumclathenter(n) = kc/(kc+ku)*((ki+ku)/(ki+ku+knc))*((knc/(ki+ku+knc))*(kc/(kc+ku)))^(n-2);
    end
    nvals = linspace(0,100,101);
    meannumclathenter(kui) = sum(nvals .* probnumclathenter);
end
h4 = semilogx(ku_list,meannumclathenter,'m--','linewidth',2);

kc = 0.1;
ki = 0.05; 
knc = 0.5; %10x higher
ku_list = logspace(-4,2,61);
for kui=1:length(ku_list)
    ku = ku_list(kui);
    probnumclathenter(1) = ku/(kc+ku);
    for n=2:101
        probnumclathenter(n) = kc/(kc+ku)*((ki+ku)/(ki+ku+knc))*((knc/(ki+ku+knc))*(kc/(kc+ku)))^(n-2);
    end
    nvals = linspace(0,100,101);
    meannumclathenter(kui) = sum(nvals .* probnumclathenter);
end
h5 = semilogx(ku_list,meannumclathenter,'m:','linewidth',2);

kc = 0.1;
ki = 0.005; %10x lower
knc = 0.05;
ku_list = logspace(-4,2,61);
for kui=1:length(ku_list)
    ku = ku_list(kui);
    probnumclathenter(1) = ku/(kc+ku);
    for n=2:101
        probnumclathenter(n) = kc/(kc+ku)*((ki+ku)/(ki+ku+knc))*((knc/(ki+ku+knc))*(kc/(kc+ku)))^(n-2);
    end
    nvals = linspace(0,100,101);
    meannumclathenter(kui) = sum(nvals .* probnumclathenter);
end
h6 = semilogx(ku_list,meannumclathenter,'b--','linewidth',2);

kc = 0.1;
ki = 0.5; %10x higher
knc = 0.05;
ku_list = logspace(-4,2,61);
for kui=1:length(ku_list)
    ku = ku_list(kui);
    probnumclathenter(1) = ku/(kc+ku);
    for n=2:101
        probnumclathenter(n) = kc/(kc+ku)*((ki+ku)/(ki+ku+knc))*((knc/(ki+ku+knc))*(kc/(kc+ku)))^(n-2);
    end
    nvals = linspace(0,100,101);
    meannumclathenter(kui) = sum(nvals .* probnumclathenter);
end
h7 = semilogx(ku_list,meannumclathenter,'b:','linewidth',2);


kc = 0.1;
ki = 0.05;
knc = 0.05;
clear ku_list
clear meannumclathenter
ku_list = 0.05;
for kui=1:length(ku_list)
    ku = ku_list(kui);
    probnumclathenter(1) = ku/(kc+ku);
    for n=2:101
        probnumclathenter(n) = kc/(kc+ku)*((ki+ku)/(ki+ku+knc))*((knc/(ki+ku+knc))*(kc/(kc+ku)))^(n-2);
    end
    nvals = linspace(0,100,101);
    meannumclathenter(kui) = sum(nvals .* probnumclathenter);
end
h8 = semilogx(ku_list,meannumclathenter,'ok','markersize',20,'LineWidth',3);

kc = 0.1;
ki = 0.05;
knc = 0.05;
clear ku_list
clear meannumclathenter
ku_list = 0.5;
for kui=1:length(ku_list)
    ku = ku_list(kui);
    probnumclathenter(1) = ku/(kc+ku);
    for n=2:101
        probnumclathenter(n) = kc/(kc+ku)*((ki+ku)/(ki+ku+knc))*((knc/(ki+ku+knc))*(kc/(kc+ku)))^(n-2);
    end
    nvals = linspace(0,100,101);
    meannumclathenter(kui) = sum(nvals .* probnumclathenter);
end
h9 = semilogx(ku_list,meannumclathenter,'o','color',[0.92 0.64 0.08],'markersize',20,'LineWidth',3);

set(gca,'fontsize',14)
xlabel('Ligand unbinding rate k_{u} (s^{-1})','fontsize',18);
ylabel('Mean clathrin entries', 'fontsize',18);
legend([h1 h2 h3 h4 h5 h6 h7], ...
    'k_{c} = 0.1 s^{-1}, k_{-c} = 0.05 s^{-1}, k_{i} = 0.05 s^{-1}', ...
    'k_{c} = 0.01 s^{-1}', ...
    'k_{c} = 1 s^{-1}', ...
    'k_{-c} = 0.005 s^{-1}', ...
    'k_{-c} = 0.5 s^{-1}', ...
    'k_{i} = 0.005 s^{-1}', ...
    'k_{i} = 0.5 s^{-1}', ...
    'fontsize',16);
box off
legend boxoff
xlim([1e-3 1e1]);

%%
%figure 3b
figure
kc = 0.1;
ki = 0.05;
knc = 0.05;
ku_list = logspace(-4,2,61);
for kui=1:length(ku_list)
    ku = ku_list(kui);
    a = 1;
    b = 2*ku + kc + knc + ki;
    c = (knc + ki + ku)*(kc + ku) - knc*kc;
    lambda1 = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));
    lambda2 = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c));
    c1 = 1/(1-((lambda1 + kc + ku)/(lambda2 + kc + ku)));
    c2 = - ((lambda1 + kc + ku)/(lambda2 + kc + ku))*c1;

    t = linspace(0,1000,100001);
    R_EGF = c1*exp(lambda1*t) + c2*exp(lambda2*t);
    Rc_EGF = (1/knc)*((kc+ku+lambda1)*c1*exp(lambda1*t) + (kc+ku+lambda2)*c2*exp(lambda2*t));
    
    P_survive_EGF = R_EGF + Rc_EGF;
    mean_t_survive(kui) = sum(0.5*(t(1:end-1)+t(2:end)) .* (P_survive_EGF(1:end-1) - P_survive_EGF(2:end)));
end

h1 = loglog(ku_list,mean_t_survive,'k','linewidth',7);
hold on

kc = 0.01; %10x lower
ki = 0.05;
knc = 0.05;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
ku_list = logspace(-4,2,61);
for kui=1:length(ku_list)
    ku = ku_list(kui);
    a = 1;
    b = 2*ku + kc + knc + ki;
    c = (knc + ki + ku)*(kc + ku) - knc*kc;
    lambda1 = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));
    lambda2 = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c));
    c1 = 1/(1-((lambda1 + kc + ku)/(lambda2 + kc + ku)));
    c2 = - ((lambda1 + kc + ku)/(lambda2 + kc + ku))*c1;

    t = linspace(0,1000,100001);
    R_EGF = c1*exp(lambda1*t) + c2*exp(lambda2*t);
    Rc_EGF = (1/knc)*((kc+ku+lambda1)*c1*exp(lambda1*t) + (kc+ku+lambda2)*c2*exp(lambda2*t));
    
    P_survive_EGF = R_EGF + Rc_EGF;
    mean_t_survive(kui) = sum(0.5*(t(1:end-1)+t(2:end)) .* (P_survive_EGF(1:end-1) - P_survive_EGF(2:end)));
end
h2 = loglog(ku_list,mean_t_survive,'--','color',[0.24 0.59 0.17],'linewidth',2);

kc = 1; %10x higher
ki = 0.05;
knc = 0.05;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
for kui=1:length(ku_list)
    ku = ku_list(kui);
    a = 1;
    b = 2*ku + kc + knc + ki;
    c = (knc + ki + ku)*(kc + ku) - knc*kc;
    lambda1 = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));
    lambda2 = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c));
    c1 = 1/(1-((lambda1 + kc + ku)/(lambda2 + kc + ku)));
    c2 = - ((lambda1 + kc + ku)/(lambda2 + kc + ku))*c1;

    t = linspace(0,1000,100001);
    R_EGF = c1*exp(lambda1*t) + c2*exp(lambda2*t);
    Rc_EGF = (1/knc)*((kc+ku+lambda1)*c1*exp(lambda1*t) + (kc+ku+lambda2)*c2*exp(lambda2*t));
    
    P_survive_EGF = R_EGF + Rc_EGF;
    mean_t_survive(kui) = sum(0.5*(t(1:end-1)+t(2:end)) .* (P_survive_EGF(1:end-1) - P_survive_EGF(2:end)));
end
h3 = loglog(ku_list,mean_t_survive,':','color',[0.24 0.59 0.17],'linewidth',2);

kc = 0.1;
ki = 0.05; 
knc = 0.005; %10x lower
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
for kui=1:length(ku_list)
    ku = ku_list(kui);
    a = 1;
    b = 2*ku + kc + knc + ki;
    c = (knc + ki + ku)*(kc + ku) - knc*kc;
    lambda1 = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));
    lambda2 = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c));
    c1 = 1/(1-((lambda1 + kc + ku)/(lambda2 + kc + ku)));
    c2 = - ((lambda1 + kc + ku)/(lambda2 + kc + ku))*c1;

    t = linspace(0,1000,100001);
    R_EGF = c1*exp(lambda1*t) + c2*exp(lambda2*t);
    Rc_EGF = (1/knc)*((kc+ku+lambda1)*c1*exp(lambda1*t) + (kc+ku+lambda2)*c2*exp(lambda2*t));
    
    P_survive_EGF = R_EGF + Rc_EGF;
    mean_t_survive(kui) = sum(0.5*(t(1:end-1)+t(2:end)) .* (P_survive_EGF(1:end-1) - P_survive_EGF(2:end)));
end
h4 = loglog(ku_list,mean_t_survive,'m--','linewidth',2);

kc = 0.1;
ki = 0.05; 
knc = 0.5; %10x higher
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
for kui=1:length(ku_list)
    ku = ku_list(kui);
    a = 1;
    b = 2*ku + kc + knc + ki;
    c = (knc + ki + ku)*(kc + ku) - knc*kc;
    lambda1 = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));
    lambda2 = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c));
    c1 = 1/(1-((lambda1 + kc + ku)/(lambda2 + kc + ku)));
    c2 = - ((lambda1 + kc + ku)/(lambda2 + kc + ku))*c1;

    t = linspace(0,1000,100001);
    R_EGF = c1*exp(lambda1*t) + c2*exp(lambda2*t);
    Rc_EGF = (1/knc)*((kc+ku+lambda1)*c1*exp(lambda1*t) + (kc+ku+lambda2)*c2*exp(lambda2*t));
    
    P_survive_EGF = R_EGF + Rc_EGF;
    mean_t_survive(kui) = sum(0.5*(t(1:end-1)+t(2:end)) .* (P_survive_EGF(1:end-1) - P_survive_EGF(2:end)));
end
h5 = loglog(ku_list,mean_t_survive,'m:','linewidth',2);

kc = 0.1;
ki = 0.005; %10x lower
knc = 0.05;
ku = logspace(-4,2,61);
Pi = kc*ki./((kc+ku).*(ki+ku) + ku.*knc);
for kui=1:length(ku_list)
    ku = ku_list(kui);
    a = 1;
    b = 2*ku + kc + knc + ki;
    c = (knc + ki + ku)*(kc + ku) - knc*kc;
    lambda1 = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));
    lambda2 = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c));
    c1 = 1/(1-((lambda1 + kc + ku)/(lambda2 + kc + ku)));
    c2 = - ((lambda1 + kc + ku)/(lambda2 + kc + ku))*c1;

    t = linspace(0,1000,100001);
    R_EGF = c1*exp(lambda1*t) + c2*exp(lambda2*t);
    Rc_EGF = (1/knc)*((kc+ku+lambda1)*c1*exp(lambda1*t) + (kc+ku+lambda2)*c2*exp(lambda2*t));
    
    P_survive_EGF = R_EGF + Rc_EGF;
    mean_t_survive(kui) = sum(0.5*(t(1:end-1)+t(2:end)) .* (P_survive_EGF(1:end-1) - P_survive_EGF(2:end)));
end
h6 = loglog(ku_list,mean_t_survive,'b--','linewidth',2);

kc = 0.1;
ki = 0.5; %10x higher
knc = 0.05;
for kui=1:length(ku_list)
    ku = ku_list(kui);
    a = 1;
    b = 2*ku + kc + knc + ki;
    c = (knc + ki + ku)*(kc + ku) - knc*kc;
    lambda1 = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));
    lambda1_rec(kui) = lambda1;
    lambda2 = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c));
    lambda2_rec(kui) = lambda2;
    c1 = 1/(1-((lambda1 + kc + ku)/(lambda2 + kc + ku)));
    c2 = - ((lambda1 + kc + ku)/(lambda2 + kc + ku))*c1;

    t = linspace(0,1000,100001);
    R_EGF = c1*exp(lambda1*t) + c2*exp(lambda2*t);
    Rc_EGF = (1/knc)*((kc+ku+lambda1)*c1*exp(lambda1*t) + (kc+ku+lambda2)*c2*exp(lambda2*t));
    
    P_survive_EGF = R_EGF + Rc_EGF;
    mean_t_survive(kui) = sum(0.5*(t(1:end-1)+t(2:end)) .* (P_survive_EGF(1:end-1) - P_survive_EGF(2:end)));
end
h7 = loglog(ku_list,mean_t_survive,'b:','linewidth',2);

kc = 0.1;
ki = 0.05;
knc = 0.05;
clear ku_list
clear mean_t_survive
ku_list = 0.05;
for kui=1:length(ku_list)
    ku = ku_list(kui);
    a = 1;
    b = 2*ku + kc + knc + ki;
    c = (knc + ki + ku)*(kc + ku) - knc*kc;
    lambda1 = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));
    lambda2 = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c));
    c1 = 1/(1-((lambda1 + kc + ku)/(lambda2 + kc + ku)));
    c2 = - ((lambda1 + kc + ku)/(lambda2 + kc + ku))*c1;

    t = linspace(0,1000,100001);
    R_EGF = c1*exp(lambda1*t) + c2*exp(lambda2*t);
    Rc_EGF = (1/knc)*((kc+ku+lambda1)*c1*exp(lambda1*t) + (kc+ku+lambda2)*c2*exp(lambda2*t));
    
    P_survive_EGF = R_EGF + Rc_EGF;
    mean_t_survive(kui) = sum(0.5*(t(1:end-1)+t(2:end)) .* (P_survive_EGF(1:end-1) - P_survive_EGF(2:end)));
end
h8 = loglog(ku_list,mean_t_survive,'ok','markersize',20,'LineWidth',3);

kc = 0.1;
ki = 0.05;
knc = 0.05;
clear ku_list
clear mean_t_survive
ku_list = 0.5;
for kui=1:length(ku_list)
    ku = ku_list(kui);
    a = 1;
    b = 2*ku + kc + knc + ki;
    c = (knc + ki + ku)*(kc + ku) - knc*kc;
    lambda1 = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));
    lambda2 = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c));
    c1 = 1/(1-((lambda1 + kc + ku)/(lambda2 + kc + ku)));
    c2 = - ((lambda1 + kc + ku)/(lambda2 + kc + ku))*c1;

    t = linspace(0,1000,100001);
    R_EGF = c1*exp(lambda1*t) + c2*exp(lambda2*t);
    Rc_EGF = (1/knc)*((kc+ku+lambda1)*c1*exp(lambda1*t) + (kc+ku+lambda2)*c2*exp(lambda2*t));
    
    P_survive_EGF = R_EGF + Rc_EGF;
    mean_t_survive(kui) = sum(0.5*(t(1:end-1)+t(2:end)) .* (P_survive_EGF(1:end-1) - P_survive_EGF(2:end)));
end
h9 = loglog(ku_list,mean_t_survive,'o','color',[0.92 0.64 0.08],'markersize',20,'LineWidth',3);

kc = 0.1;
ki = 0.05;
knc = 0.05;
ku = logspace(-4,2,61);
h10 = loglog(ku,1./ku,'--k','linewidth',2);

set(gca,'fontsize',14)
xlabel('Ligand unbinding rate k_{u} (s^{-1})','fontsize',18);
ylabel('Mean survival time (s)', 'fontsize',18);
legend([h2 h3 h4 h5 h6 h7 h1], ... ...
    'k_{c} = 0.01 s^{-1}', ...
    'k_{c} = 1 s^{-1}', ...
    'k_{-c} = 0.005 s^{-1}', ...
    'k_{-c} = 0.5 s^{-1}', ...
    'k_{i} = 0.005 s^{-1}', ...
    'k_{i} = 0.5 s^{-1}', ...
    'k_{c} = 0.1 s^{-1}, k_{-c} = 0.05 s^{-1}, k_{i} = 0.05 s^{-1}', ...
    'fontsize',14);
box off
legend boxoff
ylim([1e-1 2.5e2]);
xlim([1e-3 1e1]);

%%
%figure 3c
figure
kc = 0.1;
ki = 0.05;
knc = 0.05;
clear ku
ku = 0.05;
a = 1;
b = 2*ku + kc + knc + ki;
c = (knc + ki + ku)*(kc + ku) - knc*kc;
lambda1 = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));
lambda2 = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c));
c1 = 1/(1-((lambda1 + kc + ku)/(lambda2 + kc + ku)));
c2 = - ((lambda1 + kc + ku)/(lambda2 + kc + ku))*c1;

t = linspace(0,100,10001);
R_EGF = c1*exp(lambda1*t) + c2*exp(lambda2*t);
Rc_EGF = (1/knc)*((kc+ku+lambda1)*c1*exp(lambda1*t) + (kc+ku+lambda2)*c2*exp(lambda2*t));
plot(t,R_EGF,'b','linewidth',3);
hold on
plot(t,Rc_EGF,'r','linewidth',3);

kc = 0.1;
ki = 0.05;
knc = 0.05;
clear ku
ku = 10*0.05;
a = 1;
b = 2*ku + kc + knc + ki;
c = (knc + ki + ku)*(kc + ku) - knc*kc;
lambda1 = (1/(2*a))*(-b - sqrt(b^2 - 4*a*c));
lambda2 = (1/(2*a))*(-b + sqrt(b^2 - 4*a*c));
c1 = 1/(1-((lambda1 + kc + ku)/(lambda2 + kc + ku)));
c2 = - ((lambda1 + kc + ku)/(lambda2 + kc + ku))*c1;

t = linspace(0,100,10001);
R_notEGF = c1*exp(lambda1*t) + c2*exp(lambda2*t);
Rc_notEGF = (1/knc)*((kc+ku+lambda1)*c1*exp(lambda1*t) + (kc+ku+lambda2)*c2*exp(lambda2*t));
plot(t,R_notEGF,'b--','linewidth',3);
hold on
plot(t,Rc_notEGF,'r--','linewidth',3);

set(gca,'fontsize',14)
xlabel('Time since ligand binding (s)','fontsize',18);
ylabel('Probability of state', 'fontsize',18);
legend('Receptor outside clathrin, k_{u,EGF} = 0.05 s^{-1}', ...
    'Receptor in clathrin, k_{u,EGF} = 0.05 s^{-1}', ...
    'Receptor outside clathrin, k_{u,EREG} = 0.5 s^{-1}', ...
    'Receptor in clathrin, k_{u,EREG} = 0.5 s^{-1}', ...
    'fontsize',16);
box off
legend boxoff
xlim([0 30]);

