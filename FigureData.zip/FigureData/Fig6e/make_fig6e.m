clear all;
close all;
clc;

data_ki0p5 = load('internprobdata_ki0p5.out');
kc = 0.1;
ki = 0.5;
knc = 0.05;
ku = logspace(log10(data_ki0p5(1,1)),log10(data_ki0p5(end,1)),100);
probinterncalc = kc*ki./((kc+ku).*(ki+ku) + ku*knc);
semilogx(data_ki0p5(:,1),data_ki0p5(:,2),'.','color',[0.08 0.53 0.92],'Markersize',18);
hold on
semilogx(ku,probinterncalc,'color',[0.08 0.53 0.92],'linewidth',2);

data_ki0p05 = load('internprobdata_ki0p05.out');
kc = 0.1;
ki = 0.05;
knc = 0.05;
ku = logspace(log10(data_ki0p05(1,1)),log10(data_ki0p05(end,1)),100);
probinterncalc = kc*ki./((kc+ku).*(ki+ku) + ku*knc);
semilogx(data_ki0p05(:,1),data_ki0p05(:,2),'.','color',[0.16 0.42 0.04],'Markersize',18);
hold on
semilogx(ku,probinterncalc,'color',[0.16 0.42 0.04],'linewidth',2);

data_ki0p005 = load('internprobdata_ki0p005.out');
kc = 0.1;
ki = 0.005;
knc = 0.05;
ku = logspace(log10(data_ki0p005(1,1)),log10(data_ki0p005(end,1)),100);
probinterncalc = kc*ki./((kc+ku).*(ki+ku) + ku*knc);
semilogx(data_ki0p005(:,1),data_ki0p005(:,2),'.','color',[0.8 0.55 0.06],'Markersize',18);
hold on
semilogx(ku,probinterncalc,'color',[0.8 0.55 0.06],'linewidth',2);

set(gca,'fontsize',14)
xlabel('Ligand unbinding rate k_{u} (s^{-1})','Fontsize',18);
ylabel('Internalization probability P_{i}','Fontsize',18);
box off
legend('k_{i} = 0.5 s^{-1} spatial','k_{i} = 0.5 s^{-1} kinetic',...
    'k_{i} = 0.05 s^{-1} spatial','k_{i} = 0.05 s^{-1} kinetic',...
    'k_{i} = 0.005 s^{-1} spatial','k_{i} = 0.005 s^{-1} kinetic','fontsize',16);
legend boxoff
xlim([1e-3 1e1]);
yticks([0 0.2 0.4 0.6 0.8 1]);