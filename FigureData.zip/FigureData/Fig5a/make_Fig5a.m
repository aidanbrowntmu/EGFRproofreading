clear all;
close all;
clc;

%%
%figure 5a
data = load('firstentertimes_DeltaEenter=0.out');
data = data(1:100000);
[N,edges] = histcounts(data);
data2 = load('firstentertimes_DeltaEenter=4.4.out');
data2 = data2(1:100000);
[N2,edges2] = histcounts(data2);
data3 = load('allentertimes_DeltaEenter=4.4.out');
data3 = data3(1:100000);
[N3,edges3] = histcounts(data3);
semilogy(0.5*(edges(1:end-1)+edges(2:end)),N/(length(data)*(edges(2)-edges(1))),'.','markersize',20);
hold on
semilogy(0.5*(edges2(1:end-1)+edges2(2:end)),N2/(length(data2)*(edges2(2)-edges2(1))),'.','markersize',20);
semilogy(0.5*(edges3(1:end-1)+edges3(2:end)),N3/(length(data3)*(edges3(2)-edges3(1))),'.','markersize',20);
x = linspace(0,max(edges2),1000);
c2 = 1.88;
c3 = 2.4;
semilogy(x,(1/c3)*exp(-x/c2),'--k','linewidth',2,'markersize',20);
c2 = 9.5;
c3 = 9.5;
semilogy(x,(1/c3)*exp(-x/c2),'--k','linewidth',2,'markersize',20);
set(gca,'fontsize',14)
xlabel('Time to enter clathrin domain (s)','Fontsize',18);
ylabel('Probability density (s^{-1})','Fontsize',18);
box off
legend('First entry \DeltaE_{enter} = 0 k_{B}T','First entry \DeltaE_{enter} = 4.4 k_{B}T', ...
    'All entries \DeltaE_{enter} = 4.4 k_{B}T','fontsize',18);
legend boxoff
xlim([0 120]);
ylim([1e-5,1])

%%
%figure 5a inset
figure
[Nm,edgesm] = histcounts(data/mean(data));
[N2m,edges2m] = histcounts(data2/mean(data2));
[N3m,edges3m] = histcounts(data3/mean(data3));
semilogy(0.5*(edgesm(1:end-1)+edgesm(2:end)),Nm/(length(data)*(edgesm(2)-edgesm(1))),'.','markersize',20);
hold on
semilogy(0.5*(edges2m(1:end-1)+edges2m(2:end)),N2m/(length(data2)*(edges2m(2)-edges2m(1))),'.','markersize',20);
semilogy(0.5*(edges3m(1:end-1)+edges3m(2:end)),N3m/(length(data3)*(edges3m(2)-edges3m(1))),'.','markersize',20);
set(gca,'fontsize',18)
xlabel('Time/Mean time','Fontsize',22);
ylabel('Probability density','Fontsize',22);
box off
legend('first entry \DeltaE = 0 k_{B}T','first entry \DeltaE = 4.4 k_{B}T', ...
    'All entries \DeltaE = 4.4 k_{B}T','fontsize',18);
legend boxoff
xlim([0 12]);
ylim([1e-4 2])