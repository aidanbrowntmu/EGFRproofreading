clear all;
close all;
clc;

%figure 5c

data_0p05 = load('clathentries_successfulandattempted_ku0.05.out','w');
data_0p5 = load('clathentries_successfulandattempted_ku0.5.out','w');
numentries_0p05 = data_0p05(:,1);
penter_0p05 = data_0p05(:,2)/sum(data_0p05(:,2));
pattemptenter_0p05 = data_0p05(:,3)/sum(data_0p05(:,3));
numentries_0p5 = data_0p5(:,1);
penter_0p5 = data_0p5(:,2)/sum(data_0p5(:,2));
pattemptenter_0p5 = data_0p5(:,3)/sum(data_0p5(:,3));

bar([0 1 2 3],[penter_0p05(1:4)';penter_0p5(1:4)']);
set(gca,'fontsize',16)
xlabel('Number of clathrin entries','fontsize',20);
ylabel('Probability', 'fontsize',20);
box off
legend('k_{u} = 0.05 s^{-1} (EGF)','k_{u} = 0.5 s^{-1} (EREG)','fontsize',18);
legend boxoff
set(gca, 'XTickLabel', {'0' '1','2','3'})

%%
%figure 5d
figure
pattemptenterbinned_0p05(1) = pattemptenter_0p05(1);
pattemptenterbinned_0p05(2) = sum(pattemptenter_0p05(2:3));
pattemptenterbinned_0p05(3) = sum(pattemptenter_0p05(4:5));
pattemptenterbinned_0p05(4) = sum(pattemptenter_0p05(6:7));
pattemptenterbinned_0p05(5) = sum(pattemptenter_0p05(8:9));
pattemptenterbinned_0p05(6) = sum(pattemptenter_0p05(10:11));
pattemptenterbinned_0p05(7) = sum(pattemptenter_0p05(12:13));

pattemptenterbinned_0p5(1) = pattemptenter_0p5(1);
pattemptenterbinned_0p5(2) = sum(pattemptenter_0p5(2:3));
pattemptenterbinned_0p5(3) = sum(pattemptenter_0p5(4:5));
pattemptenterbinned_0p5(4) = sum(pattemptenter_0p5(6:7));
pattemptenterbinned_0p5(5) = sum(pattemptenter_0p5(8:9));
pattemptenterbinned_0p5(6) = sum(pattemptenter_0p5(10:11));
pattemptenterbinned_0p5(7) = sum(pattemptenter_0p5(12:13));

bar([0 1 2 3 4 5 6],[pattemptenterbinned_0p05(1:7);pattemptenterbinned_0p5(1:7)]);
set(gca,'fontsize',16)
xlabel('Number of distinct clathrin entry attempts','fontsize',20);
ylabel('Probability', 'fontsize',20);
box off
legend('k_{u} = 0.05 s^{-1} (EGF)','k_{u} = 0.5 s^{-1} (EREG)','fontsize',18);
legend boxoff
set(gca, 'XTickLabel', {'0' '1-2','3-4','5-6','7-8','9-10','11-12'})

mean_0p05 = sum(linspace(0,1000,1001)'.*pattemptenter_0p05);
mean_0p5 = sum(linspace(0,1000,1001)'.*pattemptenter_0p5);