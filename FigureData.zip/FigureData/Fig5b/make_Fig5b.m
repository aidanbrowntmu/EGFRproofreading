clear all;
close all;
clc;

data = load('firstentertimes_ku=0.05_nsamples=100000.out');
edges = linspace(0,200,401);
[N,edges] = histcounts(data,edges);
numsamples = 100000;
data2 = load('firstentertimes_DeltaEenter=4.4.out');
data2 = data2(1:100000);
[N2,edges2] = histcounts(data2,edges);
data3 = load('firstentertimes_ku=0.5_nsamples=100000.out');
[N3,edges3] = histcounts(data3,edges);
semilogy(0.5*(edges2(1:end-1)+edges2(2:end)),N2/(length(data2)*(edges2(2)-edges2(1))),'.','markersize',20);
hold on
semilogy(0.5*(edges(1:end-1)+edges(2:end)),N/(numsamples*(edges(2)-edges(1))),'.','markersize',20);
nsamples3 = 100000;
semilogy(0.5*(edges3(1:end-1)+edges3(2:end)),N3/(nsamples3*(edges3(2)-edges3(1))),'.','markersize',20);
x = linspace(0,max(edges2),1000);
c2 = 1.88;
c3 = 2.4;
c2 = 9.5;
c3 = 9.5;
semilogy(x,(1/c3)*exp(-x/c2),'--k','linewidth',2,'markersize',20);
c2 = 9.5;
c3 = 9.5;
semilogy(x,(1/c3)*exp(-x/c2).*exp(-0.05*x),'--k','linewidth',2,'markersize',20);
c2 = 9.5;
c3 = 9.5;
semilogy(x,(1/c3)*exp(-x/c2).*exp(-0.5*x),'--k','linewidth',2,'markersize',20);
set(gca,'fontsize',14)
xlabel('Time to first enter clathrin domain (s)','Fontsize',18);
ylabel('Probability density (s^{-1})','Fontsize',18);
box off
legend('k_{u} \rightarrow 0','k_{u} = 0.05 s^{-1} (EGF)', ...
    'k_{u} = 0.5 s^{-1} (EREG)','fontsize',18);
legend boxoff
xlim([0 100]);
ylim([1e-5,0.2])