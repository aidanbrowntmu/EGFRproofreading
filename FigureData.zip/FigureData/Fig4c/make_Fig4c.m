clear all;
close all;
clc;

data_E4p4first = load('internprobdata_DeltaEenter=4.4first.out');
data_E4p4all = load('internprobdata_DeltaEenter=4.4all.out');

loglog(data_E4p4first(:,1)/2.8^2,data_E4p4first(:,4),'linewidth',3);
hold on
loglog(data_E4p4all(:,1)/2.8^2,data_E4p4all(:,4),'linewidth',3);
nc = data_E4p4first(:,1);
r1 = 0.05;
rc = 0.05;
energies = 4.4;
diameter = 0.01;
D = 0.2;
clathconcentration = nc./2.8^2;
r2 = 2.8./sqrt(data_E4p4first(:,1)*pi);
tsearchmean = (1/(2*D))*((r2.^4./(r2.^2 - r1.^2)).*log(r2./r1) - (3*r2.^2 - r1.^2)./4);
mtimepredict = diameter./(2*pi*clathconcentration*rc*D).*(1./exp(-energies)) + tsearchmean;
loglog(data_E4p4first(:,1)/2.8^2,mtimepredict,'--k','linewidth',3);
loglog(data_E4p4first(:,1)/2.8^2,1./(0.02*data_E4p4first(:,1)),':k','linewidth',3);
loglog([0.1 max(data_E4p4first(:,1)/2.8^2)],[10 10],'-.k','linewidth',1);
set(gca,'fontsize',14)
xlabel('Concentration of clathrin domains c_{c} (1/\mum^{2})','Fontsize',18);
ylabel({'Mean time to enter clathrin domain (s)';'(from simulation start or last clathrin exit)'},'Fontsize',18);
box off
legend('Enter once','Enter repeatedly','t_{enter} estimate','~ 1/c_{c}','Kinetic model 1/k_{c}','fontsize',18)
legend boxoff