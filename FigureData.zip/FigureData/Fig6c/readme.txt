Data in internprobdata_nc2 (cc = 0.26), internprobdata_nc10 (cc = 1.28), and internprobdata_nc62 (cc = 7.91). The first column is k_u and the second column is P_i.
Make figures using make_Fig6c.m