clear all;
close all;
clc;

data_nc2 = load('internprobdata_nc2.out');
data_nc10 = load('internprobdata_nc10.out');
data_nc62 = load('internprobdata_nc62.out');

kc = 0.697;
ki = 0.05;
knc = 0.05;
ku = logspace(log10(data_nc62(1,1)),log10(data_nc62(end,1)),100);
probinterncalc = kc*ki./((kc+ku).*(ki+ku) + ku*knc);
semilogx(data_nc62(:,1),data_nc62(:,2),'.','color',[0.08 0.53 0.92],'Markersize',18);
hold on
semilogx(ku,probinterncalc,'color',[0.08 0.53 0.92],'linewidth',2);

kc = 0.1;
ki = 0.05;
knc = 0.05;
ku = logspace(log10(data_nc10(1,1)),log10(data_nc10(end,1)),100);
probinterncalc = kc*ki./((kc+ku).*(ki+ku) + ku*knc);
semilogx(data_nc10(:,1),data_nc10(:,2),'.','color',[0.16 0.42 0.04],'Markersize',18);
hold on
semilogx(ku,probinterncalc,'color',[0.16 0.42 0.04],'linewidth',2);

kc = 0.022;
ki = 0.05;
knc = 0.05;
ku = logspace(log10(data_nc2(1,1)),log10(data_nc2(end,1)),100);
probinterncalc = kc*ki./((kc+ku).*(ki+ku) + ku*knc);
semilogx(data_nc2(:,1),data_nc2(:,2),'.','color',[0.8 0.55 0.06],'Markersize',18);
semilogx(ku,probinterncalc,'color',[0.8 0.55 0.06],'linewidth',2);

set(gca,'fontsize',14)
xlabel('Ligand unbinding rate k_{u} (s^{-1})','Fontsize',18);
ylabel('Internalization probability P_{i}','Fontsize',18);
box off
legend('k_{c} = 0.697 s^{-1} (c_{c} = 7.91/\mum^{2}) spatial','k_{c} = 0.697 s^{-1} kinetic',...
    'k_{c} = 0.1 s^{-1} (c_{c} = 1.28/\mum^{2}) spatial','k_{c} = 0.1 s^{-1} kinetic',...
    'k_{c} = 0.022 s^{-1} (c_{c} = 0.26/\mum^{2}) spatial','k_{c} = 0.022 s^{-1} kinetic','fontsize',13);
legend boxoff
xlim([1e-3 1e1]);
yticks([0 0.2 0.4 0.6 0.8 1]);
