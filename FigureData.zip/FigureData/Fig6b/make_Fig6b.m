clear all;
close all;
clc;

data_rc0p05 = load('internprobdata_rc0.05.out');
data_rc0p0125 = load('internprobdata_rc0.0125.out');
data_rc0p2 = load('internprobdata_rc0.2.out');

kc = 0.38;
ki = 0.05;
knc = 0.05;
ku = logspace(log10(data_rc0p2(1,1)),log10(data_rc0p2(end,1)),100);
probinterncalc = kc*ki./((kc+ku).*(ki+ku) + ku*knc);
semilogx(data_rc0p2(:,1),data_rc0p2(:,2),'.','color',[0.08 0.53 0.92],'Markersize',18);
hold on
semilogx(ku,probinterncalc,'color',[0.08 0.53 0.92],'linewidth',2);

kc = 0.1;
ki = 0.05;
knc = 0.05;
ku = logspace(log10(data_rc0p05(1,1)),log10(data_rc0p05(end,1)),100);
probinterncalc = kc*ki./((kc+ku).*(ki+ku) + ku*knc);
semilogx(data_rc0p05(:,1),data_rc0p05(:,2),'.','color',[0.16 0.42 0.04],'Markersize',18);
hold on
semilogx(ku,probinterncalc,'color',[0.16 0.42 0.04],'linewidth',2);

kc = 0.029;
ki = 0.05;
knc = 0.05;
ku = logspace(log10(data_rc0p0125(1,1)),log10(data_rc0p0125(end,1)),100);
probinterncalc = kc*ki./((kc+ku).*(ki+ku) + ku*knc);
semilogx(data_rc0p0125(:,1),data_rc0p0125(:,2),'.','color',[0.8 0.55 0.06],'Markersize',18);
hold on
semilogx(ku,probinterncalc,'color',[0.8 0.55 0.06],'linewidth',2);

set(gca,'fontsize',14)
xlabel('Ligand unbinding rate k_{u} (s^{-1})','Fontsize',18);
ylabel('Internalization probability P_{i}','Fontsize',18);
box off
legend('k_{c} = 0.38 s^{-1} (r_{c} = 0.2 \mum) spatial','k_{c} = 0.38 s^{-1} kinetic',...
    'k_{c} = 0.1 s^{-1} (r_{c} = 0.05 \mum) spatial','k_{c} = 0.1 s^{-1} kinetic',...
    'k_{c} = 0.029 s^{-1} (r_{c} = 0.0125 \mum) spatial','k_{c} = 0.029 s^{-1} kinetic','fontsize',13);
legend boxoff
xlim([1e-3 1e1]);
yticks([0 0.2 0.4 0.6 0.8 1]);