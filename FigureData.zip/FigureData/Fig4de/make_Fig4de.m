clear all;
close all;
clc;

%%
%figure 4d

data_rc0p05 = load('internprobdata_rc0.05.out');
data_rc0p0125 = load('internprobdata_rc0.0125.out');
data_rc0p2 = load('internprobdata_rc0.2.out');
h2 = semilogy(data_rc0p2(:,1),data_rc0p2(:,6),'linewidth',3);
hold on
h3 = semilogy(data_rc0p05(:,1),data_rc0p05(:,6),'linewidth',3);
h4 = semilogy(data_rc0p0125(:,1),data_rc0p0125(:,6),'linewidth',3);

x = data_rc0p05(:,1);
h5 = semilogy(x,(0.05*0.01/(2*0.2))*exp(x),'--k','linewidth',3);
h6 = semilogy([min(x) max(x)], [20 20],'-.k','linewidth',1);
set(gca,'fontsize',14)
xlabel('Exit energy barrier \DeltaE_{exit} (k_{B}T)','Fontsize',18);
ylabel({'Mean time to exit clathrin domain (s)';'(since last entered)'},'Fontsize',18);
box off
legend([h5 h6 h2 h3 h4],...
    't_{exit} estimate (~ e^{\DeltaE_{exit}/(k_{B}T)})','Kinetic model 1/k_{-c}',...
    'r_{c} = 0.2 \mum','r_{c} = 0.05 \mum','r_{c} = 0.0125 \mum','fontsize',16);
legend boxoff

%%
%figure 4e
figure
data_varyrc12 = load('varyrc_DeltaE=12.out');
data_varyrc10 = load('varyrc_DeltaE=10.out');
data_varyrc8 = load('varyrc_DeltaE=8.out');
h2 = loglog(data_varyrc12(:,1),data_varyrc12(:,2),'linewidth',3);
hold on
h3 = loglog(data_varyrc10(:,1),data_varyrc10(:,2),'linewidth',3);
h4 = loglog(data_varyrc8(:,1),data_varyrc8(:,2),'linewidth',3);
h5 = loglog(data_varyrc10(:,1),(0.01*exp(10)/(2*0.2))*data_varyrc10(:,1),'--k','linewidth',3);
h5 = loglog([0.01 0.2],[20 20],'-.k','linewidth',1);
set(gca,'fontsize',14)
xlabel('Clathrin domain radius r_{c} (\mum)','Fontsize',18);
ylabel({'Mean time to exit clathrin domain (s)';'(since last entered)'},'Fontsize',18);
box off
legend('\DeltaE_{exit} = 12 k_{B}T','\DeltaE_{exit} = 10 k_{B}T','\DeltaE_{exit} = 8 k_{B}T',...
    't_{exit} estimate (~ r_{c})','Kinetic model 1/k_{-c}','fontsize',16,'numcolumns',2);
legend boxoff