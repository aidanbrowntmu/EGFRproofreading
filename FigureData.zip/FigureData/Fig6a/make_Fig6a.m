clear all;
close all;
clc;

data_kc0p58 = load('internprobdata_kc0.58.out');
kc = 0.58;
ki = 0.05;
knc = 0.05;
ku = logspace(log10(data_kc0p58(1,1)),log10(data_kc0p58(end,1)),100);
probinterncalc = kc*ki./((kc+ku).*(ki+ku) + ku*knc);
semilogx(data_kc0p58(:,1),data_kc0p58(:,2),'.','color',[0.08 0.53 0.92],'Markersize',18);
hold on
semilogx(ku,probinterncalc,'color',[0.08 0.53 0.92],'linewidth',2);

data_kc0p1 = load('internprobdata_kc0.1.out');
kc = 0.1;
ki = 0.05;
knc = 0.05;
ku = logspace(log10(data_kc0p1(1,1)),log10(data_kc0p1(end,1)),100);
probinterncalc = kc*ki./((kc+ku).*(ki+ku) + ku*knc);
semilogx(data_kc0p1(:,1),data_kc0p1(:,2),'.','color',[0.16 0.42 0.04],'Markersize',18);
hold on
semilogx(ku,probinterncalc,'color',[0.16 0.42 0.04],'linewidth',2);

data_kc0p01 = load('internprobdata_kc0.01.out');
kc = 0.01;
ki = 0.05;
knc = 0.05;
ku = logspace(log10(data_kc0p01(1,1)),log10(data_kc0p01(end,1)),100);
probinterncalc = kc*ki./((kc+ku).*(ki+ku) + ku*knc);
semilogx(data_kc0p01(:,1),data_kc0p01(:,2),'.','color',[0.8 0.55 0.06],'Markersize',18);
hold on
semilogx(ku,probinterncalc,'color',[0.8 0.55 0.06],'linewidth',2);

set(gca,'fontsize',14)
xlabel('Ligand unbinding rate k_{u} (s^{-1})','Fontsize',18);
ylabel('Internalization probability P_{i}','Fontsize',18);
box off
legend('k_{c} = 0.58 s^{-1} (\DeltaE_{enter} = 0) spatial','k_{c} = 0.58 s^{-1} kinetic',...
    'k_{c} = 0.1 s^{-1} (\DeltaE_{enter} = 4.4 k_{B}T) spatial','k_{c} = 0.1 s^{-1} kinetic',...
    'k_{c} = 0.01 s^{-1} (\DeltaE_{enter} = 7 k_{B}T) spatial','k_{c} = 0.01 s^{-1} kinetic','fontsize',13);
legend boxoff
xlim([1e-3 1e1]);
yticks([0 0.2 0.4 0.6 0.8 1]);
