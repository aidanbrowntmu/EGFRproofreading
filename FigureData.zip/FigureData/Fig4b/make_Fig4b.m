clear all;
close all;
clc;

data_mae = load('internprobdata_allenter.out');
data_mfe = load('internprobdata_firstenter.out');
loglog(data_mfe(:,1),data_mfe(:,4),'linewidth',3);
hold on
loglog(data_mae(:,1),data_mae(:,4),'linewidth',3);
x = data_mfe(:,1);

r1 = linspace(0.0125,0.2,11);
r2 = 0.5;
nc = 10;
rc = r1;
energies = 4.4;
D = 0.2;
diameter = 0.01;
clathconcentration = nc./2.8^2;
tsearchmean = (1/(2*D))*((r2.^4./(r2.^2 - r1.^2)).*log(r2./r1) - (3*r2.^2 - r1.^2)./4);
mtimepredict = diameter./(2*pi*clathconcentration*rc*D).*(1./exp(-energies)) + tsearchmean;
plot(r1,mtimepredict,'--k','linewidth',3);
loglog(x,0.4*1./x,':k','linewidth',3);
loglog([0.01 max(x)],[10 10],'-.k','linewidth',1);
set(gca,'fontsize',14)
xlabel('Clathrin domain radius r_{c} (\mum)','Fontsize',18);
ylabel({'Mean time to enter clathrin domain (s)';'(from simulation start or last clathrin exit)'},'Fontsize',18);
box off
legend('Enter once','Enter repeatedly','t_{enter} estimate','~ 1/r_{c}','Kinetic model 1/k_{c}','fontsize',18);
legend boxoff